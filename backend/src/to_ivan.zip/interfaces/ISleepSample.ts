export interface ISleepSample {
  _id: string;
  start_date: string;
  duration: Number;
  sleep_state: string;
}

export interface ISleepSampleDTO {
  _id: string;
  start_date: string;
  duration: Number;
  sleep_state: string;
}
