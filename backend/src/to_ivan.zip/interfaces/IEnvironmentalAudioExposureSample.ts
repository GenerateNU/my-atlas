export interface IEnvironmentalAudioExposureSample {
  _id: String;
  startDate: String;
  duration: Number;
  value: Number;
}

export interface IEnvironmentalAudioExposureSampleDTO {
  startDate: String;
  duration: Number;
  value: Number;
}
