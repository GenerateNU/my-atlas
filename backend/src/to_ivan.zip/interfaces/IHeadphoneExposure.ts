export interface IHeadphoneExposure {
  _id: string;
  timeStamp: string;
  duration: number;
  value: string;
}

export interface IHeadphoneExposure {
  _id: string;
  timeStamp: string;
  duration: number;
  value: string;
}
