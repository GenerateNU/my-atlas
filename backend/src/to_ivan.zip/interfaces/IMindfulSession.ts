export interface IMindfulSession {
  _id: String;
  startDate: String;
  duration: Number;
}

export interface IMindfulSessionDTO {
  startDate: String;
  duration: Number;
}
